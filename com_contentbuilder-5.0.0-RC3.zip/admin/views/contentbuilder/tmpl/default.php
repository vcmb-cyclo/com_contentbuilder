<?php
/**
 * @package     ContentBuilder
 * @author      Markus Bopp
 * @link        https://www.crosstec.org
 * @license     GNU/GPL
*/

defined('_JEXEC') or die('Restricted access');
use Joomla\CMS\Language\Text;

?>
<?php echo Text::_('COM_CONTENTBUILDER_ABOUT_DESC'); ?> <a href="https://www.crosstec.org">Crosstec Solutions</a>