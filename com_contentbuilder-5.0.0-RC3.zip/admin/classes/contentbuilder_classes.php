<?php
/**
 * @package     ContentBuilder
 * @author      Markus Bopp
 * @link        https://www.crosstec.org
 * @license     GNU/GPL
*/

defined( '_JEXEC' ) or die( 'Restricted access' );

// this is just a stub used to extend from in form element plugins
class CBFormElementAfterValidation {
    
    function onSaveRecord($record_id){
        
    }
    
    function onSaveArticle($article_id){
        
        
    }
    
}
