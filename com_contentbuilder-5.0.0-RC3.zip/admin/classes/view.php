<?php
/**
 * @package     ContentBuilder
 * @author      Markus Bopp
 * @link        https://www.crosstec.org
 * @copyright   (C) 2024 by XDA+GIL
 * @license     GNU/GPL
 */

// no direct access

defined('_JEXEC') or die ('Restricted access');

use Joomla\CMS\MVC\View\HtmlView;


class CBView extends HtmlView
{

}