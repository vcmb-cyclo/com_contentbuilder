<?php
/**
 * @package     ContentBuilder
 * @author      Markus Bopp
 * @link        https://www.crosstec.org
 * @license     GNU/GPL
*/

defined('_JEXEC') or die('Restricted access');

require_once(JPATH_SITE . DS . 'components' . DS . 'com_contentbuilder' . DS . 'views' . DS . 'list' . DS . 'tmpl' . DS . 'default.php');

